-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: magento
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `layout_update`
--

DROP TABLE IF EXISTS `layout_update`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `layout_update` (
  `layout_update_id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'Layout Update ID',
  `handle` varchar(255) DEFAULT NULL COMMENT 'Handle',
  `xml` text COMMENT 'Xml',
  `sort_order` smallint NOT NULL DEFAULT '0' COMMENT 'Sort Order',
  `updated_at` timestamp NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP COMMENT 'Last Update Timestamp',
  PRIMARY KEY (`layout_update_id`),
  KEY `LAYOUT_UPDATE_HANDLE` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3 COMMENT='Layout Updates';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `layout_update`
--

LOCK TABLES `layout_update` WRITE;
/*!40000 ALTER TABLE `layout_update` DISABLE KEYS */;
INSERT INTO `layout_update` VALUES (1,'contact_index_index','<body><referenceContainer name=\"content.top\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"zUEFbtkZjUNkEH6LxSbSM0Enms3FKDbJ\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">2</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(2,'default','<body><referenceContainer name=\"cms_footer_links_container\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"FxniuG1fZuEtQvH81mwme28cLRF3Vsfz\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">1</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(3,'catalog_category_view_id_37','<body><referenceContainer name=\"sidebar.main\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"EboGbtdc8t7vrLxVT1UlNjG5yE98xEAR\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">3</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(4,'catalog_category_view_id_3','<body><referenceContainer name=\"sidebar.main\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"WMAiqDqOaBN4bnFH8V7Si9AFJpC7MfgI\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">4</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(5,'catalog_category_view_id_11','<body><referenceContainer name=\"sidebar.main\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"LmHChBrXkIriy79GdX8WfhbeiQwn58uK\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">5</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(6,'catalog_category_view_id_20','<body><referenceContainer name=\"sidebar.main\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"Vicc2O2VxZyOu1kDhDtG2BQ8uzvYDzcr\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">6</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(7,'catalog_category_view_id_38','<body><referenceContainer name=\"sidebar.main\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"tnlWUH5rZ0lMXeZR7hZ3v82GlaRK2XGj\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">7</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(8,'catalog_category_view_id_20','<body><referenceContainer name=\"content.top\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"7egmYMIC3gohXVcWaRoLrHbTedwThOAQ\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">8</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(9,'catalog_category_view_id_9','<body><referenceContainer name=\"content.top\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"a89hdyhM7PlBgxila2GviQIf2I6WfvZg\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">9</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(10,'catalog_category_view_id_11','<body><referenceContainer name=\"content.top\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"BKNgQhwqzc9spKvyZwCgweUDXYLrqpmS\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">10</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(11,'catalog_category_view_id_3','<body><referenceContainer name=\"content.top\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"Cd8ABtB3rY4mpzI4U1ZylZH2GlGEblI0\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">11</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(12,'catalog_category_view_id_38','<body><referenceContainer name=\"content.top\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"YQQ1JHxsMYzL1jlEiFx1HEyCP16CXBBh\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">13</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(13,'catalog_category_view_id_37','<body><referenceContainer name=\"content.top\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"g7kftouaNdlLt9nWalOIzH0F0DBvMscf\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">12</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(14,'cms_index_index','<body><referenceContainer name=\"content\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"eJ7mrSrpHjl1AjXemcxPbYB6m1VFZl8A\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">14</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(15,'catalog_category_view_id_39','<body><referenceContainer name=\"content.top\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"gOjxpuflRpg5YwGqGNa4sw4nPswqE79A\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">15</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(16,'catalog_category_view_id_40','<body><referenceContainer name=\"content.top\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"Vzhg0NiMgb8vWpD6lnepybO81t4MS8vj\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">16</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(17,'customer_account_login','<body><referenceContainer name=\"customer.login.container\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"uuwj0B0vznIi3qSTaUQXQFxwJJrFKMVY\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">18</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00'),(18,'catalog_category_view_id_','<body><referenceContainer name=\"content.top\"><block class=\"Magento\\Cms\\Block\\Widget\\Block\" name=\"dYPBxmmISMGgasHjVCSG8rnGAkTBT9Gj\" template=\"widget/static_block/default.phtml\"><action method=\"setData\"><argument name=\"name\" xsi:type=\"string\">block_id</argument><argument name=\"value\" xsi:type=\"string\">17</argument></action></block></referenceContainer></body>',0,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `layout_update` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-30 20:01:00
