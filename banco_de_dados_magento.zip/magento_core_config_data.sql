-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: magento
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `core_config_data`
--

DROP TABLE IF EXISTS `core_config_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `core_config_data` (
  `config_id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'Config ID',
  `scope` varchar(8) NOT NULL DEFAULT 'default' COMMENT 'Config Scope',
  `scope_id` int NOT NULL DEFAULT '0' COMMENT 'Config Scope ID',
  `path` varchar(255) NOT NULL DEFAULT 'general' COMMENT 'Config Path',
  `value` text COMMENT 'Config Value',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Updated At',
  PRIMARY KEY (`config_id`),
  UNIQUE KEY `CORE_CONFIG_DATA_SCOPE_SCOPE_ID_PATH` (`scope`,`scope_id`,`path`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb3 COMMENT='Config Data';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `core_config_data`
--

LOCK TABLES `core_config_data` WRITE;
/*!40000 ALTER TABLE `core_config_data` DISABLE KEYS */;
INSERT INTO `core_config_data` VALUES (1,'default',0,'yotpo/module_info/yotpo_installation_date','2022-01-29','2022-01-29 17:36:33'),(2,'default',0,'yotpo/sync_settings/orders_sync_start_date','2022-01-29','2022-01-29 17:36:33'),(3,'default',0,'catalog/search/engine','elasticsearch7','2022-01-29 17:36:38'),(4,'default',0,'catalog/search/elasticsearch7_server_hostname','localhost','2022-01-29 17:36:38'),(5,'default',0,'catalog/search/elasticsearch7_server_port','9200','2022-01-29 17:36:38'),(6,'default',0,'web/seo/use_rewrites','1','2022-01-29 17:36:39'),(7,'default',0,'web/unsecure/base_url','http://localhost/magento/','2022-01-29 17:36:39'),(8,'default',0,'general/locale/code','pt_BR','2022-01-30 05:33:24'),(9,'default',0,'general/locale/timezone','America/Sao_Paulo','2022-01-30 05:33:24'),(10,'default',0,'currency/options/base','USD','2022-01-29 17:36:40'),(11,'default',0,'currency/options/default','USD','2022-01-29 17:36:40'),(12,'default',0,'currency/options/allow','USD','2022-01-29 17:36:40'),(13,'default',0,'general/region/display_all','1','2022-01-29 17:36:40'),(14,'default',0,'general/region/state_required','AL,AR,AU,BO,BR,BG,CA,CL,CN,CO,HR,DK,EC,EE,GR,GY,IS,IN,IT,LV,LT,MX,PY,PE,PL,PT,RO,ES,SR,SE,CH,US,UY,VE','2022-01-30 05:33:24'),(15,'default',0,'catalog/category/root_id','2','2022-01-29 17:42:10'),(16,'default',0,'analytics/subscription/enabled','1','2022-01-29 17:43:22'),(17,'default',0,'crontab/default/jobs/analytics_subscribe/schedule/cron_expr','0 * * * *','2022-01-29 17:43:22'),(18,'default',0,'crontab/default/jobs/analytics_collect_data/schedule/cron_expr','00 02 * * *','2022-01-29 17:43:23'),(19,'default',0,'msp_securitysuite_recaptcha/frontend/enabled','0','2022-01-29 17:43:23'),(20,'default',0,'msp_securitysuite_recaptcha/backend/enabled','0','2022-01-29 17:43:23'),(21,'default',0,'twofactorauth/duo/application_key','3GcL41q1oh1DbyD7Pdi3PrC7abkkQWujGYUykqo95Tbs2Z71fe0Yi3UfKIgSY3rF','2022-01-29 17:43:24'),(22,'default',0,'connector_dynamic_content/external_dynamic_content_urls/passcode','USEMIaBgTXAICcQO2MLJdFxhxCl8FRJn','2022-01-29 17:43:24'),(23,'default',0,'connector_developer_settings/system_alerts/user_roles','1','2022-01-29 17:43:24'),(24,'default',0,'web/secure/base_static_url','http://localhost/magento/pub/static/','2022-01-29 18:25:57'),(25,'default',0,'web/unsecure/base_static_url','http://localhost/magento/pub/static/','2022-01-29 18:25:57'),(26,'default',0,'web/secure/base_media_url','http://localhost/magento/pub/media/','2022-01-29 18:25:57'),(27,'default',0,'web/unsecure/base_media_url','http://localhost/magento/pub/media/','2022-01-29 18:25:57'),(28,'default',0,'admin/usage/enabled','0','2022-01-29 19:57:32'),(29,'stores',1,'design/theme/theme_id','2','2022-01-29 20:01:57'),(30,'websites',1,'design/theme/theme_id','2','2022-01-29 20:02:18'),(31,'default',0,'design/theme/theme_id','2','2022-01-29 20:02:27'),(32,'default',0,'design/pagination/pagination_frame','5','2022-01-29 20:02:27'),(33,'default',0,'design/pagination/pagination_frame_skip',NULL,'2022-01-29 20:02:27'),(34,'default',0,'design/pagination/anchor_text_for_previous',NULL,'2022-01-29 20:02:27'),(35,'default',0,'design/pagination/anchor_text_for_next',NULL,'2022-01-29 20:02:27'),(36,'default',0,'design/head/default_title','Magento Commerce','2022-01-29 20:02:27'),(37,'default',0,'design/head/title_prefix',NULL,'2022-01-29 20:02:27'),(38,'default',0,'design/head/title_suffix',NULL,'2022-01-29 20:02:27'),(39,'default',0,'design/head/default_description',NULL,'2022-01-29 20:02:27'),(40,'default',0,'design/head/default_keywords',NULL,'2022-01-29 20:02:27'),(41,'default',0,'design/head/includes','<link  rel=\"stylesheet\" type=\"text/css\"  media=\"all\" href=\"{{MEDIA_URL}}styles.css\" />','2022-01-29 20:23:57'),(42,'default',0,'design/head/demonotice','0','2022-01-29 20:02:27'),(43,'default',0,'design/header/logo_width',NULL,'2022-01-29 20:02:27'),(44,'default',0,'design/header/logo_height',NULL,'2022-01-29 20:02:27'),(45,'default',0,'design/header/logo_alt',NULL,'2022-01-29 20:02:27'),(46,'default',0,'design/header/welcome','Default welcome msg!','2022-01-29 20:02:27'),(47,'default',0,'design/header/translate_title','1','2022-01-29 20:02:27'),(48,'default',0,'design/footer/copyright','Copyright © 2013-present Magento, Inc. All rights reserved.','2022-01-29 20:02:27'),(49,'default',0,'design/footer/absolute_footer',NULL,'2022-01-29 20:02:27'),(50,'default',0,'design/footer/report_bugs','1','2022-01-29 20:02:27'),(51,'default',0,'design/search_engine_robots/default_robots','INDEX,FOLLOW','2022-01-29 20:02:27'),(52,'default',0,'design/search_engine_robots/custom_instructions',NULL,'2022-01-29 20:02:27'),(53,'default',0,'design/watermark/image_size',NULL,'2022-01-29 20:02:27'),(54,'default',0,'design/watermark/image_imageOpacity',NULL,'2022-01-29 20:02:27'),(55,'default',0,'design/watermark/image_position','stretch','2022-01-29 20:02:27'),(56,'default',0,'design/watermark/small_image_size',NULL,'2022-01-29 20:02:27'),(57,'default',0,'design/watermark/small_image_imageOpacity',NULL,'2022-01-29 20:02:27'),(58,'default',0,'design/watermark/small_image_position','stretch','2022-01-29 20:02:27'),(59,'default',0,'design/watermark/thumbnail_size',NULL,'2022-01-29 20:02:27'),(60,'default',0,'design/watermark/thumbnail_imageOpacity',NULL,'2022-01-29 20:02:27'),(61,'default',0,'design/watermark/thumbnail_position','stretch','2022-01-29 20:02:27'),(62,'default',0,'design/email/logo_alt',NULL,'2022-01-29 20:02:27'),(63,'default',0,'design/email/logo_width',NULL,'2022-01-29 20:02:27'),(64,'default',0,'design/email/logo_height',NULL,'2022-01-29 20:02:27'),(65,'default',0,'design/email/header_template','design_email_header_template','2022-01-29 20:02:27'),(66,'default',0,'design/email/footer_template','design_email_footer_template','2022-01-29 20:02:27'),(67,'default',0,'carriers/tablerate/active','1','2022-01-29 20:25:21'),(68,'default',0,'carriers/tablerate/condition_name','package_value_with_discount','2022-01-29 20:25:21'),(69,'default',0,'sales/msrp/enabled','1','2022-01-29 20:25:26'),(70,'default',0,'general/country/destinations',NULL,'2022-01-30 05:33:19'),(71,'default',0,'general/locale/weight_unit','kgs','2022-01-30 05:33:24'),(72,'default',0,'general/store_information/name',NULL,'2022-01-30 05:33:24'),(73,'default',0,'general/store_information/phone',NULL,'2022-01-30 05:33:24'),(74,'default',0,'general/store_information/hours',NULL,'2022-01-30 05:33:24'),(75,'default',0,'general/store_information/country_id',NULL,'2022-01-30 05:33:24'),(76,'default',0,'general/store_information/region_id',NULL,'2022-01-30 05:33:24'),(77,'default',0,'general/store_information/postcode',NULL,'2022-01-30 05:33:24'),(78,'default',0,'general/store_information/city',NULL,'2022-01-30 05:33:24'),(79,'default',0,'general/store_information/street_line1',NULL,'2022-01-30 05:33:24'),(80,'default',0,'general/store_information/street_line2',NULL,'2022-01-30 05:33:24'),(81,'default',0,'general/store_information/merchant_vat_number',NULL,'2022-01-30 05:33:24'),(82,'default',0,'general/single_store_mode/enabled','0','2022-01-30 05:33:24'),(83,'default',0,'general/country/default','BR','2022-01-30 05:34:45'),(84,'default',0,'general/country/optional_zip_countries','BR','2022-01-30 05:34:45'),(85,'default',0,'system/full_page_cache/varnish/access_list','localhost','2022-01-30 05:35:02'),(86,'default',0,'system/full_page_cache/varnish/backend_host','localhost','2022-01-30 05:35:02'),(87,'default',0,'system/full_page_cache/varnish/backend_port','8080','2022-01-30 05:35:02'),(88,'default',0,'system/full_page_cache/varnish/grace_period','300','2022-01-30 05:35:02');
/*!40000 ALTER TABLE `core_config_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-30 20:01:08
