-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: magento
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `catalog_product_entity_varchar`
--

DROP TABLE IF EXISTS `catalog_product_entity_varchar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `catalog_product_entity_varchar` (
  `value_id` int NOT NULL AUTO_INCREMENT COMMENT 'Value ID',
  `attribute_id` smallint unsigned NOT NULL DEFAULT '0' COMMENT 'Attribute ID',
  `store_id` smallint unsigned NOT NULL DEFAULT '0' COMMENT 'Store ID',
  `entity_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'Entity ID',
  `value` varchar(255) DEFAULT NULL COMMENT 'Value',
  PRIMARY KEY (`value_id`),
  UNIQUE KEY `CATALOG_PRODUCT_ENTITY_VARCHAR_ENTITY_ID_ATTRIBUTE_ID_STORE_ID` (`entity_id`,`attribute_id`,`store_id`),
  KEY `CATALOG_PRODUCT_ENTITY_VARCHAR_ATTRIBUTE_ID` (`attribute_id`),
  KEY `CATALOG_PRODUCT_ENTITY_VARCHAR_STORE_ID` (`store_id`),
  CONSTRAINT `CAT_PRD_ENTT_VCHR_ATTR_ID_EAV_ATTR_ATTR_ID` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE,
  CONSTRAINT `CAT_PRD_ENTT_VCHR_ENTT_ID_CAT_PRD_ENTT_ENTT_ID` FOREIGN KEY (`entity_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE,
  CONSTRAINT `CATALOG_PRODUCT_ENTITY_VARCHAR_STORE_ID_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `store` (`store_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15253 DEFAULT CHARSET=utf8mb3 COMMENT='Catalog Product Varchar Attribute Backend Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_product_entity_varchar`
--

LOCK TABLES `catalog_product_entity_varchar` WRITE;
/*!40000 ALTER TABLE `catalog_product_entity_varchar` DISABLE KEYS */;
INSERT INTO `catalog_product_entity_varchar` VALUES (1,73,0,1,'Angular 9'),(2,123,0,1,'joust-duffle-bag'),(3,87,0,1,'//a/n/angular.png'),(4,88,0,1,'//a/n/angular.png'),(5,89,0,1,'//a/n/angular.png'),(15066,114,0,1,'BR'),(15067,134,0,1,'0'),(15068,120,0,1,'0'),(15069,106,0,1,'container1'),(15071,109,0,1,'Image'),(15073,110,0,1,'Image'),(15075,111,0,1,'Image'),(15088,114,0,2041,'BR'),(15089,134,0,2041,'2'),(15090,87,0,2041,'//v/u/vue.jpeg'),(15091,86,0,2041,'Vue JS #html-body [data-pb-style=V9SSQ8T]{justify-content:flex-start;display:flex;flex-direction:column;background-position:left top;background-size:cover;background-repeat:no-repeat;background-attachment:scroll}Com mais de 150k de estrelas no Github,&nbs'),(15092,84,0,2041,'Vue JS'),(15093,120,0,2041,'0'),(15094,73,0,2041,'Vue JS'),(15095,106,0,2041,'container2'),(15096,104,0,2041,'product-full-width'),(15097,88,0,2041,'//v/u/vue.jpeg'),(15098,135,0,2041,'//v/u/vue.jpeg'),(15099,89,0,2041,'//v/u/vue.jpeg'),(15100,123,0,2041,'vue-js'),(15109,114,0,2042,'BR'),(15110,134,0,2042,'2'),(15111,87,0,2042,'//r/e/react.png'),(15112,86,0,2042,'React JS #html-body [data-pb-style=N6WY4XJ]{justify-content:flex-start;display:flex;flex-direction:column;background-position:left top;background-size:cover;background-repeat:no-repeat;background-attachment:scroll}DeclarativoReact faz com que a criação de'),(15113,84,0,2042,'React JS'),(15114,120,0,2042,'0'),(15115,73,0,2042,'React JS'),(15116,106,0,2042,'container2'),(15117,104,0,2042,'product-full-width'),(15118,88,0,2042,'//r/e/react.png'),(15119,135,0,2042,'//r/e/react.png'),(15120,89,0,2042,'//r/e/react.png'),(15121,123,0,2042,'react-js'),(15126,114,0,2043,'BR'),(15127,134,0,2043,'2'),(15128,87,0,2043,'//l/a/laravel-8.png'),(15129,86,0,2043,'Laravel 8 #html-body [data-pb-style=LONA8I2]{justify-content:flex-start;display:flex;flex-direction:column;background-position:left top;background-size:cover;background-repeat:no-repeat;background-attachment:scroll}Por que Laravel?Há uma variedade de ferr'),(15130,84,0,2043,'Laravel 8'),(15131,120,0,2043,'0'),(15132,73,0,2043,'Laravel 8'),(15133,106,0,2043,'container2'),(15134,104,0,2043,'product-full-width'),(15135,88,0,2043,'//l/a/laravel-8.png'),(15136,135,0,2043,'//l/a/laravel-8.png'),(15137,89,0,2043,'//l/a/laravel-8.png'),(15138,123,0,2043,'laravel-8'),(15143,134,0,2044,'2'),(15144,87,0,2044,'//p/h/php_8_released.png'),(15145,86,0,2044,'PHP 8 #html-body [data-pb-style=KRTP6HN]{justify-content:flex-start;display:flex;flex-direction:column;background-position:left top;background-size:cover;background-repeat:no-repeat;background-attachment:scroll}As principais Novidades do PHP 8A nova versã'),(15146,84,0,2044,'PHP 8'),(15147,120,0,2044,'0'),(15148,73,0,2044,'PHP 8'),(15149,106,0,2044,'container2'),(15150,104,0,2044,'product-full-width'),(15151,88,0,2044,'//p/h/php_8_released.png'),(15152,135,0,2044,'//p/h/php_8_released.png'),(15153,89,0,2044,'//p/h/php_8_released.png'),(15154,123,0,2044,'php-8'),(15159,134,0,2045,'2'),(15160,87,0,2045,'//c/_/c_.png'),(15161,86,0,2045,'C# 9 #html-body [data-pb-style=Q4RLD7Y]{justify-content:flex-start;display:flex;flex-direction:column;background-position:left top;background-size:cover;background-repeat:no-repeat;background-attachment:scroll}O C# 9 continua três dos temas de versões ant'),(15162,84,0,2045,'C# 9'),(15163,120,0,2045,'0'),(15164,73,0,2045,'C# 9'),(15165,106,0,2045,'container2'),(15166,104,0,2045,'product-full-width'),(15167,88,0,2045,'//c/_/c_.png'),(15168,135,0,2045,'//c/_/c_.png'),(15169,89,0,2045,'//c/_/c_.png'),(15170,123,0,2045,'c-9'),(15175,134,0,2046,'2'),(15176,87,0,2046,'//2/0/2014-11-14-java-logo.jpg'),(15177,86,0,2046,'Java 8 #html-body [data-pb-style=E38QBTT]{justify-content:flex-start;display:flex;flex-direction:column;background-position:left top;background-size:cover;background-repeat:no-repeat;background-attachment:scroll}Funcionalidades do Java 8Aqui há um breve r'),(15178,84,0,2046,'Java 8'),(15179,120,0,2046,'0'),(15180,73,0,2046,'Java 8'),(15181,106,0,2046,'container2'),(15182,104,0,2046,'product-full-width'),(15183,88,0,2046,'//2/0/2014-11-14-java-logo.jpg'),(15184,135,0,2046,'//2/0/2014-11-14-java-logo.jpg'),(15185,89,0,2046,'//2/0/2014-11-14-java-logo.jpg'),(15186,123,0,2046,'java-8'),(15208,138,0,1,'24'),(15215,138,0,2041,'25'),(15224,138,0,2042,'26'),(15233,139,0,2043,'31'),(15238,141,0,2044,'70'),(15243,141,0,2045,'69'),(15248,141,0,2046,'71');
/*!40000 ALTER TABLE `catalog_product_entity_varchar` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-30 20:00:55
